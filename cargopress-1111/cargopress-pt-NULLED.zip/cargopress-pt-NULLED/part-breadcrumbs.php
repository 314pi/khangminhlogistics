<?php if ( function_exists( 'bcn_display' ) ) { ?>
	<div class="breadcrumbs">
		<div class="container">
			<?php bcn_display(); ?>
		</div>
	</div>
<?php } ?>
