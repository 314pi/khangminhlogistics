/* global define, jQuery */
/**
 * jQuery module fix
 */
define( [], function () {
	'use strict';
	return jQuery;
} );