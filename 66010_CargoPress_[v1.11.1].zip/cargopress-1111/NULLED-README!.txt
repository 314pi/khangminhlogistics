1. Install and activate ".../cargopress-pt-NULLED"
2. Install and activate all plugins
Import demo / Options work
Do not attempt to register a template! Everything is working